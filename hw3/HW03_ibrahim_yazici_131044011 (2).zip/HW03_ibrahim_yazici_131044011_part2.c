/*==========================================================*/
/*ibrahim yazici 131044011                                  */
/*finds and calculates a functions first derivate	    */
/*==========================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define SIZE 30
#define E_NATURAL 2.718
#define PI 3.14159

/*Function comments are below*/
int part2(void);
double derivative(const int numberOfElements,double *result2);
void printArray(const char *temp, int size);
void arrayDivide(const char *f, char temp[][SIZE], int numberOfElements, int tempSize);
double dydx(char temp[][SIZE], int index, int valueOfX);
int xWithConstant(char temp[][SIZE], int index);
int xWithPow(char temp[][SIZE], int index, int valueOfX);
int isNumber(char ch);
int isX(char ch);
int isPow(char ch);

int main()
{
/*START_OF_MAIN*/
    part2();

    return 0;
/*END_OF_MAIN*/
}

int part2(void)
{
    double result;
    double result2;
    int numberOfElements;
    printf("\t>MAX_SIZE THAT THE FUNCTION CAN HOLD IS 30 CHARACTERS<\n");
    printf("E = 2.718, PI = 3.14159\n");
    printf("After entering number of elements you msut follow this rules below\n");
    printf("1-Enter them one by one after PRESSING ENTER. for 5x^2 you should press 5 enter x enter ^ enter 2 enter\n");
    printf("More examples of input system\n");
    printf("for   5x^3+3x+5 ->   5 x ^ 3 + 3 x + 5 = (pressing enter after each)\n");
    printf("for   sin(x) + e^x ->   s i n ( x ) + e ^ x = (pressing enter after each)\n");
    printf("for   6cos(x) + 2x^1/2 ->   6 c o s ( x ) + 2 x ^ 1 / 2 = (pressing enter after each)\n");
    printf("ONE LAST TIME I WANT TO MAKE MYSELF SURE THAT YOU UNDERSTAND HOW YOU ENTER THEM :D.ON CONSOLE SCREEN IT LOOKS LIKE THIS\n");
    printf("if the number of elements are 2 and the function is sin(x)+2x^2");
    printf("\ns\ni\nn\n(\nx\n)\n+\n2\nx\n^\n2\n=\n");
    printf("2-When you are done type + for the next element\n");
    printf("3-When you enter all of the elements PRESS = then enter\n\n");


    printf("Number of the elements:");
    scanf("%d", &numberOfElements);

    result = derivative(numberOfElements, &result2);
    printf("\n   y = %f(call by value)\n",result);
    printf("   y = %f(call by reference)\n",result);

    return 0;
}
/*Prints array*/
void printArray(const char *temp, int size)
{
    int i;
    i = 0;
    printf("\nFunction is y = ");
    while(i < size)
    {
        printf("%c",temp[i]);
        i++;
    }
    printf("\n");
}

double derivative(const int numberOfElements, double *result2)
{
    /*Variables*/
    char divided[SIZE][SIZE];
    char f[SIZE];
    int check;
    int i;
    int tempSize;
    int counter;
    int valueOfX;
    double result;
    tempSize = 0;
    counter = 0;
    result = 0;
    for(i = 0; i < SIZE; ++i)
    {
        printf("Element:");
        scanf(" %c",&f[i]);
        if(f[i] == '\0')
            i = SIZE;
        else if(f[i] == '+')
            check++;
        if(check == numberOfElements)
        {
             printf("You overloaded...\n");
             i = SIZE;
        }
        else if(f[i] == '=')
            i = SIZE;
        tempSize++;
    }
    /*printf("temp size:%d\n",tempSize);*/
    f[tempSize - 1] = '\0';
    printArray(f,tempSize - 1);

    printf("Enter the value of x to be used in the f'() :");
    scanf("%d",&valueOfX);

    counter = 0;
    i = 0;
    arrayDivide(f, divided, numberOfElements,tempSize);

    /* continue heeereeeeeeeeeee*/
    printf("dy/dx = ");
    while(counter < numberOfElements)
    {
        result = result + dydx(divided,counter,valueOfX);
        counter++;
    }
    *result2 = result;

    printf("\nfor x = %d",valueOfX);
    return result;
}
/*MAIN DERIVATIVE FUNCTION*/
double dydx(char temp[][SIZE],int index,int valueOfX)
{
    /*Variables*/
    /*char *der = NULL;*/
    int i;
    int constant;
    int test;
    double result;
    i = 0;
    /*Checking if it is like cosx*/
    test = 0;
    while(temp[index][i] != '\0')
    {
        if(strstr(temp[index],"cos"))
            test = 1;
        i++;
    }
    if(test == 1)
    {
        /*printf("\n<cos>\n");*/
        if(atoi(temp[index]) == 0)
            constant = 1;
        else
            constant = atoi(temp[index]);
        result = constant * sin(valueOfX * PI / 180);
        printf("%d-sin(x)",constant);
        return -result;
    }
    i = 0;
    /*Checking if it is a constant*/
    test = 1;
    while(temp[index][i] != '\0')
    {
        if(isNumber(temp[index][i]) != 1)
        {
            test = 0;
        }

        i++;
    }
    if(test == 1)
    {
        /*printf("\n<constant>\n");*/
        temp[index][0] = '0';
        temp[index][1] = '\0';
        /*printf("%s",temp[index]);*/
        printf("+ 0");
        return 0;
    }

    i = 0;
    /*If it is like 5x, 10x or x*/
    test = 0;
    while(temp[index][i] != '\0')
    {

        if(isPow(temp[index][i]) == 1 || strstr(temp[index],"sin") != NULL)
        {
            test = 1;
        }

        i++;
    }
    if(test == 0)
    {
         /*printf("\n<ax>\n");*/
        /*printf("%d x with constant\n",index);*/
        xWithConstant(temp,index);
        i = 0;
        while(temp[index][i] != '\0')
        {
            if(temp[index][i] == 'x')
                temp[index][i] = '\0';
            i++;
        }
        /*printf("%s",temp[index]);*/
        if(atoi(temp[index]) == 0)
            printf("+ 1");
        else
            printf("+ %d",atoi(temp[index]));
        if(atoi(temp[index]) == 0)
            return 1;
        return atoi(temp[index]);
    }

    i = 0;
    /*If it is like x^2, 5x^4*/
    test = 0;
    while(temp[index][i] != '\0')
    {

        if(isPow(temp[index][i]) == 1 && strstr(temp[index], "e^") == NULL && strstr(temp[index],"1/2") == NULL && strstr(temp[index],"sin") == NULL)
            test = 1;
        i++;
    }
    if(test == 1)
    {
        /*printf("\n<ax^a>\n");*/
        /*printf("%d x with pow\n",index);*/
        result = xWithPow(temp,index,valueOfX);
        i = 0;

        while(temp[index][i] != '\0')
        {
            if(temp[index][i] == 'x')
                temp[index][i] = '\0';
            i++;
        }
        /*printf("%s",temp[index]);*/
        return result;
    }
    i = 0;
    /*If it is like 6e^x*/
    test = 0;
    while(temp[index][i] != '\0')
    {

        /*printf("<%s>\n",temp[index]);*/
        if(strstr(temp[index],"e^") != NULL && strstr(temp[index],"1/2") == NULL && strstr(temp[index],"sin") == NULL)
            test = 1;
        i++;
    }
    if(test == 1)
    {
       /* printf("\n<ae^x>\n");*/
        i = 0;
        while(temp[index][i] != 'x')
            i++;
        if(atoi(temp[index]) == 0)
            constant = 1;
        else
            constant = atoi(temp[index]);

        result = constant * pow(E_NATURAL,valueOfX);
        printf("+ %de^x",constant);
        return result;
    }
    i = 0;
    /*If it is like 5x^1/2*/
    test = 0;
    while(temp[index][i] != '\0')
    {

        if(strstr(temp[index],"1/2") && strstr(temp[index],"sin") == NULL)
            test = 1;
        i++;
    }
    if(test == 1)
    {
        /*printf("\n<a^1/2>\n");*/
        i = 0;
        if(atoi(temp[index]) == 0)
            constant = 1;
        else
            constant = atoi(temp[index]);
        result = 0.5 * constant / sqrt(valueOfX);
        printf("+ %fx^-(1/2)", 0.5 * constant);
        return result;
    }
     i = 0;
    /*If it is like sin(x)*/
    test = 0;
    while(temp[index][i] != '\0')
    {
        if(strstr(temp[index],"sin"))
            test = 1;
        i++;
    }
    if(test == 1)
    {
        /*printf("\n<sinx>\n");*/
        if(atoi(temp[index]) == 0)
            constant = 1;
        else
            constant = atoi(temp[index]);
        result = constant * cos(valueOfX * PI / 180);
        printf("+%dcos(x)",constant);
        return result;
    }
    return 0;
}
int xWithPow(char temp[][SIZE],int index, int valueOfX)
{
    /*Variables*/
    int numb;
    int tempNumb;
    int result;
    int i;
    i = 0;
    result = 0;
    while(temp[index][i] != '^')
        i++;

    /*("\ni+1=%c\n",temp[index][i+1]);*/
    tempNumb = temp[index][i+1] - '0';
    temp[index][i+1] = tempNumb - 1 + '0';
    if(atoi(temp[index]) == 0)
        numb = tempNumb;
    else
        numb = tempNumb * atoi(temp[index]);
    /*printf("tempnumb=%d\n",tempNumb);*/
    temp[index][i] = numb + '0';
    /*printf("numb=%d\n",numb);*/
    /*printf("+%s\n",temp[index]);*/
    printf("+ %dx^%d",numb,tempNumb-1);
    /*printf("vlaueofX=%d\n",valueOfX);*/
    result = numb * pow(valueOfX,temp[index][i+1] - '0');
    /*printf("<result = %d>\n",result);*/
    return result;

}
int xWithConstant(char temp[][SIZE],int index)
{
    int numb;
    numb = atoi(temp[index]);
    /*printf("%d",numb);*/
    return numb;
}
/*Checking if is a number*/
int isNumber(char ch)
{
    if(ch == '0' || ch == '1' || ch == '2' || ch == '3' || ch == '4' || ch == '5' ||
       ch == '6' || ch == '7' || ch == '8' || ch == '9' || ch == ' ')
    {
        /*if it is a number returns 1*/
        return 1;
    }
    return 0;
}
/*If it contains only x or number*/
int isX(char ch)
{
    if(ch == 'x')
        return 1;
    return 0;
}
/*If it contains only x or number and ^*/
int isPow(char ch)
{
    if(ch == '^')
        return 1;
    return 0;
}

/*Divides the function into its elements*/
/*3x^2+4x+2 becomes 3x^2 4x and 2.They are stored in different arrays to be calculated easier*/
void arrayDivide(const char *f, char temp[][SIZE], int numberOfElements, int tempSize)
{
    int i;
    int counter;
    int pos;
    int pos2;
    pos2 = 0;
    pos = 0;
    i = 0;
    counter = 0;
    while(counter < numberOfElements)
    {
        if(counter == numberOfElements - 1)
        {
            pos = tempSize-1;

            for(i = pos2; i < pos; ++i)
            {
                if(counter  == 0)
                    temp[counter][i-pos2] = f[i];
                else
                    temp[counter][i-pos2] = f[i];
                /*printf("%c",temp[counter][i-pos2]);*/
            }
        }
        else
        {
            for(i = pos + 1; i < SIZE; ++i)
            {
                if(f[i] == '+')
                {
                   pos = i;
                   i = SIZE;
                }
                else if(f[i] == '\0')
                {
                   pos = i;
                   i = SIZE;
                }
            }
            for(i = pos2; i < pos; ++i)
            {
                if(counter  == 0)
                    temp[counter][i-pos2] = f[i];
                else
                    temp[counter][i-pos2] = f[i];
                /*printf("%c",temp[counter][i-pos2]);*/
            }
        }
        /*printf("\n");*/
        /*printf("pos %d   pos 2  %d\n",pos,pos2);*/
        temp[counter][i-pos2] = '\0';
        pos2 = pos+1;
        counter++;
    }
    counter = 0;
}










