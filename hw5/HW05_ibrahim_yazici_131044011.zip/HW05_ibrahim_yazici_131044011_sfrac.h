#ifndef HW05_ibrahim_yazici_131044011_sfrac_h
#define HW05_ibrahim_yazici_131044011_sfrac_h

/*Functions that we are to use in the homework*/
void sfrac_simplify(char * n);

char * sfrac_add(char * n1, char * n2);

char * sfrac_sub(char * n1, char * n2);

char * sfrac_negat(char * n);

char * sfrac_mult(char * n1, char * n2);

char * sfrac_div(char * n1, char * n2);

char * sfrac_fromdouble(char *t, double x);

double sfrac_todouble(char * x);

void sfrac_print(char *a1, char *n1, char *a2, char *n2, char *a3, char *n3, char *a4);

#endif
