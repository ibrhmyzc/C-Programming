
#include "HW05_ibrahim_yazici_131044011_sfrac.h"
#include "string.h"
#include <stdio.h>
#include <stdlib.h>

void sfrac_simplify(char * n)
{
    char *temp;
    char result1[100],result2[100];
    char seperator[] = "/";
    int i, divide = 1, smaller, numerator=0, denominator=0;

    numerator = atoi(n);
    temp = strtok(n, seperator);
    temp = strtok(NULL, seperator);
    denominator = atoi(temp);

    if(abs(numerator) > abs(denominator))
        smaller = denominator;
    else
        smaller = numerator;

    /*Finds the gdc of two numbers*/
    for(i = 1; i <= abs(smaller); ++i)
    {
        if(numerator % i == 0 && denominator % i == 0)
        {
            divide = i;
        }
    }

    numerator = numerator / divide;
    denominator = denominator / divide;

    if(numerator * denominator < 0 && denominator < 0)
    {
        denominator = denominator * -1;
    }
    else if(numerator * denominator > 0 && denominator < 0)
    {
        numerator = numerator * -1;
        denominator = denominator * -1;

    }

    sprintf(result1,"%d",numerator);
    sprintf(result2,"%d",denominator);

    n[0] = '\0';
    strcat(n,result1);
    strcat(n,"/");
    strcat(n,result2);

}

char * sfrac_add(char * n1, char * n2)
{
    char result1[100],result2[100];
    char seperator[] = "/";
    char *temp;
    int position=0, numerator1=0, numerator2=0, denominator1=0, denominator2=0;
    int totalNumerator=0, totalDenominator=0;


    /*for n1*/
    numerator1 = atoi(n1);
    temp = strtok(n1, seperator);
    temp = strtok(NULL, seperator);
    denominator1 = atoi(temp);

    /*for n2*/
    numerator2 = atoi(n2);
    temp = strtok(n2, seperator);
    temp = strtok(NULL, seperator);
    denominator2 = atoi(temp);

    /*rational number sum*/
    totalNumerator = numerator1 * denominator2 + numerator2 * denominator1;
    totalDenominator = denominator1 * denominator2;

    if(totalNumerator == 0)
    {
        n1[0] = '0';
        n1[1] = '\0';
        return n1;
    }
    if(totalDenominator * totalNumerator < 0)
        position++;

    sprintf(result1,"%d",totalNumerator);
    sprintf(result2,"%d",totalDenominator);

    n1[0] = '\0';
    strcat(n1,result1);
    strcat(n1,"/");
    strcat(n1,result2);


    /*Simplify the result*/
    sfrac_simplify(n1);
    return n1;
}

char * sfrac_sub(char * n1, char * n2)
{
    char result1[100],result2[100];
    char seperator[] = "/";
    char *temp;
    int position=0, numerator1=0, numerator2=0, denominator1=0, denominator2=0;
    int totalNumerator=0, totalDenominator=0;

    /*for n1*/
    numerator1 = atoi(n1);
    temp = strtok(n1, seperator);
    temp = strtok(NULL, seperator);
    denominator1 = atoi(temp);

    /*for n2*/
    numerator2 = atoi(n2);
    temp = strtok(n2, seperator);
    temp = strtok(NULL, seperator);
    denominator2 = atoi(temp);

    /*rational number sum*/
    totalNumerator = numerator1 * denominator2 - numerator2 * denominator1;
    totalDenominator = denominator1 * denominator2;

    if(totalNumerator == 0)
    {
        n1[0] = '0';
        n1[1] = '\0';
        return n1;
    }
    if(totalDenominator * totalNumerator < 0)
        position++;

    sprintf(result1,"%d",totalNumerator);
    sprintf(result2,"%d",totalDenominator);

    n1[0] = '\0';
    strcat(n1,result1);
    strcat(n1,"/");
    strcat(n1,result2);

    /*Simplify the result*/
    sfrac_simplify(n1);
    return n1;
}

char * sfrac_negat(char * n)
{
    char *temp;
    char result1[100],result2[100];
    char seperator[] = "/";
    int  numerator=0, denominator=0;

    /*Seperating the numerator and denominator*/
    numerator = atoi(n);
    temp = strtok(n, seperator);
    temp = strtok(NULL, seperator);
    denominator = atoi(temp);


    /*Negates it*/
    numerator = numerator * -1;
    denominator = denominator ;

    sprintf(result1,"%d",numerator);
    sprintf(result2,"%d",denominator);

    n[0] = '\0';
    strcat(n,result1);
    strcat(n,"/");
    strcat(n,result2);
    sfrac_simplify(n);
    return n;
}

char * sfrac_mult(char * n1, char * n2)
{
    char result1[100],result2[100];
    char seperator[] = "/";
    char *temp;
    int position=0, numerator1=0, numerator2=0, denominator1=0, denominator2=0;
    int totalNumerator=0, totalDenominator=0;

    /*for n1*/
    numerator1 = atoi(n1);
    temp = strtok(n1, seperator);
    temp = strtok(NULL, seperator);
    denominator1 = atoi(temp);

    /*for n2*/
    numerator2 = atoi(n2);
    temp = strtok(n2, seperator);
    temp = strtok(NULL, seperator);
    denominator2 = atoi(temp);

    /*rational number mult*/
    totalNumerator = numerator1 * numerator2;
    totalDenominator = denominator1 * denominator2;

    /*If it is zero*/
    if(totalNumerator == 0)
    {
        n1[0] = '0';
        n1[1] = '\0';
        return n1;
    }
    if(totalDenominator * totalNumerator < 0)
        position++;

    /*Writing the integer to a string*/
    sprintf(result1,"%d",totalNumerator);
    sprintf(result2,"%d",totalDenominator);

    n1[0] = '\0';
    strcat(n1,result1);
    strcat(n1,"/");
    strcat(n1,result2);

    /*Simplify the result*/
    sfrac_simplify(n1);
    return n1;
}

char * sfrac_div(char * n1, char * n2)
{
    char result1[100],result2[100];
    char seperator[] = "/";
    char *temp;
    int position=0, numerator1=0, numerator2=0, denominator1=0, denominator2=0;
    int totalNumerator=0, totalDenominator=0;

    /*for n1*/
    numerator1 = atoi(n1);
    temp = strtok(n1, seperator);
    temp = strtok(NULL, seperator);
    denominator1 = atoi(temp);

    /*for n2*/
    numerator2 = atoi(n2);
    temp = strtok(n2, seperator);
    temp = strtok(NULL, seperator);
    denominator2 = atoi(temp);

    /*rational number div*/
    totalNumerator = numerator1 * denominator2;
    totalDenominator = denominator1 * numerator2;

    /*If it is zero*/
    if(totalNumerator == 0)
    {
        n1[0] = '0';
        n1[1] = '\0';
        return n1;
    }
    if(totalDenominator * totalNumerator < 0)
        position++;

    /*Writing the integer to a string*/
    sprintf(result1,"%d",totalNumerator);
    sprintf(result2,"%d",totalDenominator);

    n1[0] = '\0';
    strcat(n1,result1);
    strcat(n1,"/");
    strcat(n1,result2);

    /*Simplify the result*/
    sfrac_simplify(n1);
    return n1;
}

char * sfrac_fromdouble(char *t, double x)
{
    int doublePart, fracPartInt;
    char temp1[100], temp2[100];
    double fracPart;

    doublePart = (int)x;
    fracPart = x - doublePart;

    /*For maximum 6 digits after comma*/
    fracPart = fracPart * 1000000;
    /*When i tried to  multiply and cast, for examples, .350 it showed me  349.999. So i added 1 to deal with this problem*/
    fracPartInt = (int)fracPart + 1;

    while(fracPartInt % 10 == 0)
    {
        fracPartInt = fracPartInt / 10;
    }

    sprintf(temp1, "%d", doublePart);
    sprintf(temp2, "%d", fracPartInt);

    t[0] = '\0';
    strcat(t,temp1);
    strcat(t,"/");
    strcat(t,temp2);

    return t;
}

double sfrac_todouble(char * x)
{
    char *temp;
    char backup[100];
    char seperator[] = "/";
    int numerator=0, denominator=0;
    double result;


    numerator = atoi(backup);
    temp = strtok(backup, seperator);
    temp = strtok(NULL, seperator);
    denominator = atoi(temp);

    /*To get rid of integer div*/
    result = ((double)numerator) / denominator;

    return result;
}

void sfrac_print(char *a1, char *n1, char *a2, char *n2, char *a3, char *n3, char *a4)
{
    char result1[100],result2[100];
    char seperator[] = "/";
    char *temp;
    int position=0, numerator1=0, numerator2=0,numerator3=0, denominator1=0, denominator2=0, denominator3=0;
    int totalNumerator=0, totalDenominator=0;

     /*for n1*/
    numerator1 = atoi(n1);
    temp = strtok(n1, seperator);
    temp = strtok(NULL, seperator);
    denominator1 = atoi(temp);

    /*for n2*/
    numerator2 = atoi(n2);
    temp = strtok(n2, seperator);
    temp = strtok(NULL, seperator);
    denominator2 = atoi(temp);

    /*for n3*/
    numerator3 = atoi(n3);
    temp = strtok(n3, seperator);
    temp = strtok(NULL, seperator);
    denominator3 = atoi(temp);

    printf("%11d%9d%9d\n",numerator1, numerator2, numerator3);
    printf("%s ----- %s ----- %s ----- %s\n",a1, a2, a3, a4);
    printf("%11d%9d%9d\n",denominator1, denominator2, denominator3);
}






