/*-----------------------------------------------------*/
/*CS 102 HW5 Part1 Ibrahim Yazici 131044011            */
/*This program does calculations vis string	       */
/*-----------------------------------------------------*/
#include <stdio.h>
#include "HW05_ibrahim_yazici_131044011_sfrac.h"
#include <string.h>

int main()
{
/*START_OF_MAIN*/
    /*Variables*/
    char n1[100];
    char n2[100];
    char backup1[100], backup2[100], temp[100];
    char operation;

    printf("Input your operation as in the following format 2/3 34/45 -34/101...\n");

    printf("first rational number:");
    scanf("%s",n1);

    printf("Which operation would you like to perform? + - * or :");
    scanf(" %c",&operation);

    printf("second rational number:");
    scanf("%s",n2);

    /*We will not use the original strings*/
    strcpy(backup1, n1);
    strcpy(backup2, n2);

    switch(operation)
    {
    case '+':
        strcpy(backup1, sfrac_add(n1, n2));
        printf("Result is:%s",backup1);
        break;
    case '-':
        strcpy(backup1, sfrac_sub(n1, n2));
        printf("Result is:%s",backup1);
        break;
    case '*':
        strcpy(backup1, sfrac_mult(n1, n2));
        printf("Result is:%s",backup1);
        break;
    case ':':
        strcpy(backup1, sfrac_div(n1, n2));
        printf("Result is:%s",backup1);
        break;
    default:
        printf("Operation is invalid\n");
    }

    return 0;
/*END_OF_MAIN*/
}
