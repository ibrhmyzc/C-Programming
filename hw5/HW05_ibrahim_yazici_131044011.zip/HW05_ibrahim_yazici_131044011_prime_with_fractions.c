/*************************************************/
/*Ibrahim Yazici 131044011 HW05 Part 2           */
/*This program shows the first 1000 prime numbers*/
/*************************************************/
#include "HW05_ibrahim_yazici_131044011_sfrac.h"
#include <stdio.h>

int main()
{
/*START_OF_MAIN*/
    /*Variables*/
    int max=1000, i=0, j, check=0;
    printf("I could not use the library I made in the previous part of the homework.\n");
    printf("At least I try write this program without previous library functions... \n");

    if(i < 0 || i == 0 || i ==1)
        printf("\n>Negative numbers, 0 and 1 can not be prime<\n");

    printf("\n*************************************************************\n");

    /*max is initialized above*/
    for(i = 2; i < max; ++i)
    {
        /*We start j from 2 because 0 is invalid and 1 can divide all the numbers*/
        for(j = 2; j < i; ++j)
        {
            /*Even numbers and a number, which can be divided by other than itself, can not be prime*/
            if((i % j == 0) || (i % 2 == 0))
            {
                /*if it is not a prime number, here we end the second loop*/
                j = i;
                /*and here we use a check*/
                check = 1;
            }
        }
        /*If check is not 1, we know that we found a prime number above*/
        if(check != 1)
            printf("%d,", i);
        /*Showing the numbers by groups*/
        if(i%100 == 0)
            printf("\n");
        /*Resetting the check for further use*/
        check = 0;
    }
    printf("\n*************************************************************\n");
    return 0;
/*END_OF_MAIN*/
}
