/*==========================================================*/
/*ibrahim yazici 131044011                                  */
/*this program gets number of terms and the angle form user */
/* to calculate sinus value using taylor                    */
/*==========================================================*/
#include <stdio.h>

#define PI 3.14159

int part1(void);
/*taylor function*/
double taylor(int angle, int term);
/*This function returns the value of a^b */
double pow(double a, double b);
/*This function returns teh factorial of a number*/
int factorial(int numb);

int main()
{
/*START_OF_MAIN*/
    part1();

    return 0;
/*END_OF_MAIN */
}

int part1(void)
{
    /*Variables to be used in function*/
    int angle;
    int numberOfTerms;

    /*Getting angle and terms from the user*/
    printf("Please enter the angle in degrees:");
    scanf("%d", &angle);

    printf("PLease enter the number of terms :");
    scanf("%d", &numberOfTerms);
    /*if it is illegal*/
    if(numberOfTerms < 0)
    {
        printf("Number of terms must not me negative\n");
        return 1;
    }
    else if(numberOfTerms > 7)
    {
        printf("Due to integer limits, number of terms must not exceed 7\n");
        return 1;
    }


    taylor(angle, numberOfTerms);

    return 0;
}/*45 = pi/4*/

double taylor(int angle, int term)
{
    int i;
    int temp;
    double radian;
    double result;
    /*Initializing the result before */
    result = 0;
    /*this goes on like this 1,-1,1,-1,1*/
    temp = 1;

    /*If angle is greater than 180*/
    if(angle > 180)
    {
        angle = angle % 180;
        /*Changing the starting sign*/
        temp = -1;
    }

    /*Converting degree to radian*/
    radian = PI * angle / 180.0;


    for(i = 0; i < term; ++i)
    {
        if(temp == 1)
            result = result + (pow(radian,2 * i + 1) / factorial(2 * i + 1));
        else
            result = result - (pow(radian,2 * i + 1) / factorial(2 * i + 1));
        /*Changing its sign to perform taylor series*/
        temp = -temp;

    }
    printf("\nThe result is  :%.8f\n",result);
    return result;

}
double pow(double a, double b)
{
    /*Variables*/
    int i;
    double result;
    result = a;

    for(i = 1; i < (int)b; i++)
        result *= a;

    return result;
}

int factorial(int numb)
{
    /*Variables*/
    int i;
    int result;
    result = 1;
    for(i = 1; i < numb + 1; ++i)
        result = result * i;

    return result;
}





